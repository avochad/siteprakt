export function Header({ onRegisterClick }: { onRegisterClick: () => void }) {
  return (
    <header className="border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 py-6 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <h1 className="tracking-wide">EVERMORE</h1>
          <nav className="hidden md:flex gap-6">
            <a href="#" className="text-neutral-600 hover:text-neutral-900">Женщинам</a>
            <a href="#" className="text-neutral-600 hover:text-neutral-900">Мужчинам</a>
            <a href="#" className="text-neutral-600 hover:text-neutral-900">О нас</a>
          </nav>
        </div>
        <div className="flex items-center gap-6">
          <button onClick={onRegisterClick} className="text-neutral-600 hover:text-neutral-900">Регистрация</button>
          <a href="#" className="text-neutral-600 hover:text-neutral-900">Корзина</a>
        </div>
      </div>
    </header>
  );
}
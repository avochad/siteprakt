export function RegisterPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h2 className="mb-2">Создать аккаунт</h2>
          <p className="text-neutral-600">Присоединяйтесь к нашему сообществу</p>
        </div>
        
        <form className="bg-white p-8 border border-neutral-200">
          <div className="mb-6">
            <label htmlFor="name" className="block mb-2 text-neutral-700">
              Имя
            </label>
            <input
              type="text"
              id="name"
              className="w-full px-4 py-3 border border-neutral-300 focus:outline-none focus:border-neutral-900"
              placeholder="Введите ваше имя"
            />
          </div>

          <div className="mb-6">
            <label htmlFor="email" className="block mb-2 text-neutral-700">
              Email
            </label>
            <input
              type="email"
              id="email"
              className="w-full px-4 py-3 border border-neutral-300 focus:outline-none focus:border-neutral-900"
              placeholder="your@email.com"
            />
          </div>

          <div className="mb-6">
            <label htmlFor="password" className="block mb-2 text-neutral-700">
              Пароль
            </label>
            <input
              type="password"
              id="password"
              className="w-full px-4 py-3 border border-neutral-300 focus:outline-none focus:border-neutral-900"
              placeholder="Минимум 8 символов"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-neutral-900 text-white py-3 hover:bg-neutral-800 transition-colors mb-4"
          >
            Зарегистрироваться
          </button>

          <p className="text-center text-neutral-600">
            Уже есть аккаунт?{' '}
            <a href="#" className="text-neutral-900 underline">
              Войти
            </a>
          </p>
        </form>
      </div>
    </div>
  );
}

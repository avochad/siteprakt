import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';

const productImages = [
  'https://images.unsplash.com/photo-1610765987208-06bbd5d2a1a8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwc3dlYXRlciUyMGtuaXR3ZWFyfGVufDF8fHx8MTc2NDY1ODMxNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'https://images.unsplash.com/photo-1667586680656-6b8e381cddb5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWlnZSUyMGNhc2htZXJlJTIwc3dlYXRlcnxlbnwxfHx8fDE3NjQ2NTg3NDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  'https://images.unsplash.com/photo-1597954424044-cef1e74a89ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrbml0d2VhciUyMGRldGFpbCUyMHRleHR1cmV8ZW58MXx8fHwxNzY0NjU4NzQ3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
];

export function ProductPage() {
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState('M');

  const sizes = ['XS', 'S', 'M', 'L', 'XL'];

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Изображения */}
          <div>
            <div className="bg-neutral-100 mb-4 aspect-square">
              <ImageWithFallback
                src={productImages[selectedImage]}
                alt="Кашемировый свитер"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {productImages.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`bg-neutral-100 aspect-square ${
                    selectedImage === index ? 'ring-2 ring-neutral-900' : ''
                  }`}
                >
                  <ImageWithFallback
                    src={image}
                    alt={`Вид ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Информация о товаре */}
          <div>
            <h1 className="mb-4">Кашемировый свитер</h1>
            <p className="mb-6 text-neutral-600">11 000 ₽</p>

            <div className="mb-8">
              <p className="text-neutral-700 leading-relaxed">
                Роскошный свитер из 100% кашемира премиум качества. 
                Мягкий, теплый и невероятно комфортный. Идеально подходит 
                для повседневной носки в прохладную погоду.
              </p>
            </div>

            <div className="mb-8">
              <h3 className="mb-4">Размер</h3>
              <div className="flex gap-3">
                {sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`w-16 h-12 border ${
                      selectedSize === size
                        ? 'border-neutral-900 bg-neutral-900 text-white'
                        : 'border-neutral-300 hover:border-neutral-900'
                    } transition-colors`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <button className="w-full bg-neutral-900 text-white py-4 hover:bg-neutral-800 transition-colors mb-4">
              Добавить в корзину
            </button>

            <div className="border-t border-neutral-200 pt-8 mt-8">
              <h3 className="mb-4">Детали</h3>
              <ul className="space-y-2 text-neutral-600">
                <li>• 100% кашемир</li>
                <li>• Произведено в Италии</li>
                <li>• Ручная стирка в холодной воде</li>
                <li>• Свободный крой</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

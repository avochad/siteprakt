import { ImageWithFallback } from './figma/ImageWithFallback';

const products = [
  {
    id: 1,
    name: 'Классическая футболка',
    price: 2500,
    image: 'https://images.unsplash.com/photo-1485920784995-d65789b1c3af?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aGl0ZSUyMHRzaGlydCUyMG1pbmltYWx8ZW58MXx8fHwxNzY0NjE3MzQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: 2,
    name: 'Джинсы из хлопка',
    price: 7800,
    image: 'https://images.unsplash.com/photo-1601673125183-a1221a59ff4f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwamVhbnMlMjBkZW5pbXxlbnwxfHx8fDE3NjQ2MTQwMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  },
  {
    id: 3,
    name: 'Кашемировый свитер',
    price: 11000,
    image: 'https://images.unsplash.com/photo-1610765987208-06bbd5d2a1a8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwc3dlYXRlciUyMGtuaXR3ZWFyfGVufDF8fHx8MTc2NDY1ODMxNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
  }
];

export function ProductGrid({ onProductClick }: { onProductClick: () => void }) {
  return (
    <section className="max-w-7xl mx-auto px-4 py-16">
      <h3 className="mb-12">Бестселлеры</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {products.map((product) => (
          <div 
            key={product.id} 
            className="group cursor-pointer"
            onClick={product.id === 3 ? onProductClick : undefined}
          >
            <div className="bg-neutral-100 mb-4 overflow-hidden aspect-[3/4]">
              <ImageWithFallback
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div>
              <p className="text-neutral-900 mb-1">{product.name}</p>
              <p className="text-neutral-600">{product.price} ₽</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  return (
    <div className="relative h-[600px] bg-neutral-100">
      <ImageWithFallback
        src="https://images.unsplash.com/photo-1507297448044-a99b358cd06e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsJTIwZmFzaGlvbiUyMGNsb3RoaW5nfGVufDF8fHx8MTc2NDU1MTEyNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
        alt="Fashion collection"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center text-white">
          <h2 className="mb-4">Новая коллекция</h2>
          <p className="mb-8 text-neutral-200">Простые, классические вещи на каждый день</p>
          <button className="bg-white text-neutral-900 px-8 py-3 hover:bg-neutral-100 transition-colors">
            Купить
          </button>
        </div>
      </div>
    </div>
  );
}